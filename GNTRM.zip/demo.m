

%% first normalize the intensities of the data to the range of [0,1]
load data1

%% Please see our paper for the detailed setting of these parameters, 
%% which need to be tuned to give the best fusion results for different MS datasets
alpha = 3e-1;
beta = 1;
eta  = 1e-4;
tau  = 0.01;
Maxit   = 300;
[Imag]  = GNTRM(lowMS,Pan,Maxit,alpha,beta,eta,tau);





